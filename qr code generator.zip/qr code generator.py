import qrcode
#taking UPI ID As a input
upi_id = input("Enter your UPI ID = ")

#upi:/pay?pa=UPI_ID&pn=NAME&am=Amount&cu=CURRENCY&tn=MESSAGE

#defining the payment URL based on the UPI ID and the payment app
#you can modify these URLs based on the payment apps you want to support

jazzcash_url = f'upi://pay?pa={upi_id}&pn=Recipient%20Name$mc=123'
easypaisa_url = f'upi://pay?pa={upi_id}&pn=Recipient%20Name$mc=123'
google_pay_url = f'upi://pay?pa={upi_id}&pn=Recipient%20Name$mc=123'

#create QR code for each payment app
jazzcash_qr = qrcode.make(jazzcash_url)
easypaisa_qr = qrcode.make(easypaisa_url)
google_pay_qr = qrcode.make(google_pay_url)

#save the QR code to image file (optional)
jazzcash_qr.save('jazzcash_qr.png')
easypaisa_qr.save('easypaisa_qr.png')
google_pay_qr.save('google_pay_qr.png')

#display the AR codes (you may need to install PIL(pillow library))
jazzcash_qr.show()
easypaisa_qr.show()
google_pay_qr.show()