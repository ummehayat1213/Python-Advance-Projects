class hotelfarecal:

    def __init__(self, rt='', s=0, p=0, r=0, t=0, a=1800, name='', address='', cindate='', coutdate='', rno=101):
        print("\n\n*****WELCOME TO AHUR HOTEL*****\n")
        self.rt = rt
        self.r = r
        self.t = t
        self.p = p
        self.s = s
        self.a = a
        self.name = name
        self.address = address
        self.cindate = cindate
        self.coutdate = coutdate
        self.rno = rno

    def inputdata(self):
        self.name = input("\nEnter your name:")
        self.address = input("\nEnter your address:")
        self.cindate = input("\nEnter your check-in date:")
        self.coutdate = input("\nEnter your checkout date:")
        print("Your room no.:", self.rno, "\n")

    def roomrent(self):
        print("We have the following rooms for you:-")
        print("1.  type A---->rs 7000 PN\-")
        print("2.  type B---->rs 6000 PN\-")
        print("3.  type C---->rs 5000 PN\-")
        print("4.  type D---->rs 4000 PN\-")

        x = int(input("Enter Your Choice Please->"))
        n = int(input("For How Many Nights Did You Stay:"))

        if x == 1:
            print("You have opted room type A")
            self.s = 7000 * n
        elif x == 2:
            print("You have opted room type B")
            self.s = 6000 * n
        elif x == 3:
            print("You have opted room type C")
            self.s = 5000 * n
        elif x == 4:
            print("You have opted room type D")
            self.s = 4000 * n
        else:
            print("Please choose a valid room")

        print("Your room rent is =", self.s, "\n")

    def restaurantbill(self):
        print("*****RESTAURANT MENU*****")
        print("1. Water----->Rs50", "2. Tea----->Rs80", "3. Breakfast Combo--->Rs200",
              "4. Lunch---->Rs510", "5. Dinner--->Rs700", "6. Exit")

        while True:
            c = int(input("Enter your choice:"))
            if c == 1:
                d = int(input("Enter the quantity:"))
                self.r += 50 * d
            elif c == 2:
                d = int(input("Enter the quantity:"))
                self.r += 80 * d
            elif c == 3:
                d = int(input("Enter the quantity:"))
                self.r += 200 * d
            elif c == 4:
                d = int(input("Enter the quantity:"))
                self.r += 510 * d
            elif c == 5:
                d = int(input("Enter the quantity:"))
                self.r += 700 * d
            elif c == 6:
                break
            else:
                print("Invalid option")

        print("Total food cost = Rs", self.r, "\n")

    def laundrybill(self):
        print("******LAUNDRY MENU*******")
        print("1. Shorts----->Rs40", "2. Trousers----->Rs60", "3. Shirt--->Rs60",
              "4. Jeans---->Rs60", "5. Girlsuit--->Rs80", "6. Exit")

        while True:
            e = int(input("Enter your choice:"))
            if e == 1:
                f = int(input("Enter the quantity:"))
                self.t += 40 * f
            elif e == 2:
                f = int(input("Enter the quantity:"))
                self.t += 60 * f
            elif e == 3:
                f = int(input("Enter the quantity:"))
                self.t += 60 * f
            elif e == 4:
                f = int(input("Enter the quantity:"))
                self.t += 60 * f
            elif e == 5:
                f = int(input("Enter the quantity:"))
                self.t += 80 * f
            elif e == 6:
                break
            else:
                print("Invalid option")

        print("Total Laundry Cost = Rs", self.t, "\n")

    def gamebill(self):
        print("******GAME MENU*******")
        print("1. Table tennis----->Rs60", "2. Bowling----->Rs80", "3. Snooker--->Rs70",
              "4. Video games---->Rs90", "5. Pool--->Rs50", "6. Exit")

        while True:
            g = int(input("Enter your choice:"))
            if g == 1:
                h = int(input("No. of hours:"))
                self.p += 60 * h
            elif g == 2:
                h = int(input("No. of hours:"))
                self.p += 80 * h
            elif g == 3:
                h = int(input("No. of hours:"))
                self.p += 70 * h
            elif g == 4:
                h = int(input("No. of hours:"))
                self.p += 90 * h
            elif g == 5:
                h = int(input("No. of hours:"))
                self.p += 50 * h
            elif g == 6:
                break
            else:
                print("Invalid option")

        print("Total Game Bill = Rs", self.p, "\n")

    def display(self):
        print("******HOTEL BILL******")
        print("Customer details:")
        print("Customer name:", self.name)
        print("Customer address:", self.address)
        print("Check in date:", self.cindate)
        print("Check out date", self.coutdate)
        print("Room no.", self.rno)
        print("Your Room rent is:", self.s)
        print("Your Food bill is:", self.r)
        print("Your Laundry bill is:", self.t)
        print("Your Game bill is:", self.p)

        self.rt = self.s + self.t + self.p + self.r
        print("Your sub total bill is:", self.rt)
        print("Additional Service Charges is", self.a)
        print("Your grand total bill is:", self.rt + self.a, "\n")
        self.rno += 1


def main():
    a = hotelfarecal()

    while True:
        print("1. Enter Customer Data")
        print("2. Calculate room rent")
        print("3. Calculate restaurant bill")
        print("4. Calculate laundry bill")
        print("5. Calculate game bill")
        print("6. Show total cost")
        print("7. EXIT")

        b = int(input("\nEnter your choice:"))
        if b == 1:
            a.inputdata()
        elif b == 2:
            a.roomrent()
        elif b == 3:
            a.restaurantbill()
        elif b == 4:
            a.laundrybill()
        elif b == 5:
            a.gamebill()
        elif b == 6:
            a.display()
        elif b == 7:
            quit()


main()
