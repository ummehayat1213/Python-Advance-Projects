# Define the menu of the restaurant
menu = {
    'pasta': 800,
    'pizza': 1200,
    'russian salad': 450,
    'cold drink': 100,
    'burger': 350,
    'coffee': 200,
    'tea': 80,
}

# Print greetings
print("Welcome to TASTE Cafe")
print("Pasta: Rs800\nPizza: Rs1200\nRussian Salad: Rs450\nCold Drink: Rs100\nBurger: Rs350\nCoffee: Rs200\nTea: Rs80")

total_order = 0

# Get the first order
item_1 = input("Enter the name of the item you would like to order: ")
if item_1 in menu:
    total_order += menu[item_1]
    print(f"Your item '{item_1}' has been placed.")
else:
    print(f"Sorry! The item '{item_1}' is not available. You can order something else.")

# Check if the user wants to order something else
another_order = input("Do you want to order something else? (Yes/No): ")
if another_order == "yes":
    item_2 = input("Enter the name of the second item: ")
    if item_2 in menu:
        total_order += menu[item_2]
        print(f"Your item '{item_2}' has been placed.")
    else:
        print(f"Sorry! The item '{item_2}' is not available. You can order something else.")

# Print the total amount
print(f"The total amount for the items is Rs{total_order}.")
