from itertools import cycle
from PIL import Image, ImageTk
import time
import tkinter as tk

# Create the main window
root = tk.Tk()
root.title("Image Slideshow Viewer")

# List of image paths (ensure commas between paths)
Image_paths = [
    r"D:\Python Projects\Screenshot 2023-09-03 070653.gif",
    r"D:\Python Projects\view-delicious-healthy-cantaloupe-melon_23-2151658972.jpg",
    r"D:\Python Projects\purple-cabbage-floor_23-2147953432.jpg",
    r"D:\Python Projects\colorful-bell-pepper_1203-6833.jpg"
]

# Resize images to 1080x1080
image_size = (1080, 1080)
images = [Image.open(path).resize(image_size) for path in Image_paths]
photo_images = [ImageTk.PhotoImage(image) for image in images]

# Label to display images
label = tk.Label(root)
label.pack()

# Cycle through the photo images
slideshow = cycle(photo_images)

def update_image():
    """Update the label with the next image."""
    next_image = next(slideshow)
    label.config(image=next_image)
    # Call this function again after 2 seconds
    root.after(2000, update_image)

def start_slideshow():
    """Start the slideshow."""
    update_image()

# Play button to start the slideshow
play_button = tk.Button(root, text='Play Slideshow', command=start_slideshow)
play_button.pack()

# Start the Tkinter event loop
root.mainloop()
