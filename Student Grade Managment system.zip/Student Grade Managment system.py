students_grades = {}

# add a new student 
def add_student(name, grade):
    students_grades[name] = grade
    print(f"Added {name} with a grade of {grade}")

# update a student 
def update_student(name, grade):
    if name in students_grades:
        students_grades[name] = grade
        print(f"{name}'s grade has been updated to {grade}")
    else:
        print(f"{name} is not found!")

# delete student 
def del_student(name):
    if name in students_grades:
        del students_grades[name]
        print(f"{name} has been successfully deleted")
    else:
        print(f"{name} is not found!")

# view all students
def display_all_students():
    if students_grades:
        for name, grade in students_grades.items():
            print(f"{name} : {grade}")
    else:
        print("No students found/added")

# main 
def main():
    while True:
        print("\nStudent Grades Management System")
        print("1. Add Student") 
        print("2. Update Student") 
        print("3. Delete Student") 
        print("4. View Students") 
        print("5. Exit") 

        choice = int(input("Enter your choice: "))

        if choice == 1:
            name = input("Enter student name: ")
            grade = int(input("Enter student grade: "))
            add_student(name, grade)

        elif choice == 2:
            name = input("Enter student name: ")
            grade = int(input("Enter student grade: "))
            update_student(name, grade)

        elif choice == 3:
            name = input("Enter student name: ")
            del_student(name)

        elif choice == 4:
            display_all_students()

        elif choice == 5:
            print("Closing the program...")
            break

        else:
            print("Invalid choice")

# Run the main function
main()
