#!/usr/bin/python
import getpass

# creating lists of users, their PINs, and bank statements
users = ['user', 'user2', 'user3']
pins = ['1234', '2222', '3333']
amounts = [1000, 2000, 3000]
count = 0

# User Authentication
while True:
    user = input('\nENTER USER NAME: ').lower()
    if user in users:
        n = users.index(user)  # Get the index of the user
        break
    else:
        print('----------------')
        print('****************')
        print('INVALID USERNAME')
        print('****************')
        print('----------------')

# PIN verification (3 attempts allowed)
while count < 3:
    pin = getpass.getpass('PLEASE ENTER PIN: ')
    if pin == pins[n]:  # Check the pin for the respective user
        break
    else:
        count += 1
        print('-----------')
        print('***********')
        print('INVALID PIN')
        print('***********')
        print('-----------')

# Lock the card after 3 failed attempts
if count == 3:
    print('-----------------------------------')
    print('***********************************')
    print('3 UNSUCCESSFUL PIN ATTEMPTS, EXITING')
    print('!!!!!YOUR CARD HAS BEEN LOCKED!!!!!')
    print('***********************************')
    print('-----------------------------------')
    exit()

print('LOGIN SUCCESSFUL, CONTINUE')
print(f'Welcome {users[n].capitalize()} to the ATM')

# Main menu
while True:
    response = input('\nSELECT FROM FOLLOWING OPTIONS: \n'
                     'Statement__(S) \nWithdraw___(W) \n'
                     'Lodgement__(L) \nChange PIN_(P) \nQuit_______(Q) \n: ').lower()

    if response == 's':  # Show balance
        print(f'{users[n].capitalize()}, YOU HAVE {amounts[n]} EURO ON YOUR ACCOUNT.')
        
    elif response == 'w':  # Withdraw money
        cash_out = int(input('ENTER AMOUNT YOU WOULD LIKE TO WITHDRAW: '))
        if cash_out % 10 != 0:
            print('AMOUNT MUST BE IN MULTIPLES OF 10 EURO NOTES')
        elif cash_out > amounts[n]:
            print('YOU HAVE INSUFFICIENT BALANCE')
        else:
            amounts[n] -= cash_out
            print(f'YOUR NEW BALANCE IS: {amounts[n]} EURO')
            
    elif response == 'l':  # Deposit money
        cash_in = int(input('ENTER AMOUNT YOU WANT TO LODGE: '))
        if cash_in % 10 != 0:
            print('AMOUNT MUST BE IN MULTIPLES OF 10 EURO NOTES')
        else:
            amounts[n] += cash_in
            print(f'YOUR NEW BALANCE IS: {amounts[n]} EURO')
            
    elif response == 'p':  # Change PIN
        new_pin = getpass.getpass('ENTER A NEW PIN: ')
        if new_pin.isdigit() and len(new_pin) == 4 and new_pin != pins[n]:
            confirm_pin = getpass.getpass('CONFIRM NEW PIN: ')
            if confirm_pin == new_pin:
                pins[n] = new_pin
                print('NEW PIN SAVED')
            else:
                print('PIN MISMATCH')
        else:
            print('NEW PIN MUST BE 4 DIGITS AND DIFFERENT FROM PREVIOUS PIN')
            
    elif response == 'q':  # Quit
        print('Thank you for using the ATM. Goodbye!')
        exit()
        
    else:
        print('INVALID OPTION')
