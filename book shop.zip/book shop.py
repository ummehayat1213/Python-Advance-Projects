books = { 
    'Urdu': 200,
    'English': 300,
    'Science': 300,
    'Computer': 250,
    'General Knowledge': 150,
    'Islamiyat': 350,
    'Pakistan Study': 350,
    'Copy': 80,
    'Note Book': 120,
    'Pen': 70,
    'Marker': 50,
    'Ballpoint': 60,
}

# Welcome to the Book shop
print("Welcome to the Book Shop")
print("Urdu: Rs200\nEnglish: Rs300\nScience: Rs300\nComputer: Rs250\nGeneral Knowledge: Rs150\nIslamiyat: Rs350\nPakistan Study: Rs350\nCopy: Rs80\nNote Book: Rs120\nPen: Rs70\nMarker: Rs50\nBallpoint: Rs60")

total_order = 0
 
item_1 = input("May I assist you! Tell me what you want: ")
if item_1 in books:
    total_order += books[item_1]
    print(f"This '{item_1}' is available here.")
else:
    print("Sorry! This is not available here.")

another_item = input("Would you like something else? (Yes/No): ")
if another_item.lower() == 'yes':
    item_2 = input("Which one would you like more: ")
    if item_2 in books:
        total_order += books[item_2]
        print(f"This '{item_2}' is available here.")
    else:
        print("Sorry! This is not available here.")
else:
    print("Okay, thank you for your purchase!")

print(f"The total amount of your bill is Rs{total_order}.")
